package com.techm.classes;

public class StoreLoc {
	
	private int locationId;
	private String city;
	
	
	
	public StoreLoc(int locationId, String city) {
		super();
		this.locationId = locationId;
		this.city = city;
	}
	
	
	public int getLocationId() {
		return locationId;
	}
	public void setLocationId(int locationId) {
		this.locationId = locationId;
	}
	public String getCity() {
		return city;
	}
	public void setLocation(String city) {
		this.city = city;
	}
	
	
	@Override
	public String toString() {
		return "StoreLoc [locationId=" + locationId + ", city=" + city
				+ "]";
	}
	
	
	

}
