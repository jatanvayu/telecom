package com.techm.classes;



public class Customer{
	private String Username;
	private String password;
	private String city;
	private String email;
	private long cellNo;
	
		
	public Customer(String username, String password, String city,
			String email, long cellNo) {
		super();
		Username = username;
		this.password = password;
		this.city = city;
		this.email = email;
		this.cellNo = cellNo;
	}
	
	
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getCellNo() {
		return cellNo;
	}
	public void setCellNo(long cellNo) {
	
		this.cellNo = cellNo;
	}
	
	
	
	
	@Override
	public String toString() {
		return "Customer [Username=" + Username + ", password=" + password
				+ ", city=" + city + ", email=" + email + ", cellNo=" + cellNo
				+ "]";
	}
	
	
	

}
