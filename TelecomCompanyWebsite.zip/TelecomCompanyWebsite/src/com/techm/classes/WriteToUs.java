package com.techm.classes;

public class WriteToUs {
	
	
	
	private int faqId;
	private String query;
	private int status;
	private String answer;
	
	
	
	public WriteToUs(int faqId, String query, int status, String answer) {
		super();
		this.faqId = faqId;
		this.query = query;
		this.status = status;
		this.setAnswer(answer);
	}
	
	
	public WriteToUs() {
		// TODO Auto-generated constructor stub
	}


	public int getFaqId() {
		return faqId;
	}
	public void setFaqId(int faqId) {
		this.faqId = faqId;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	
	
	
	

	

	@Override
	public String toString() {
		return "WriteToUs [faqId=" + faqId + ", query=" + query + ", status="
				+ status + ", answer=" + answer + "]";
	}


	public int getStatus() {
		return status;
	}


	public void setStatus(int status) {
		this.status = status;
	}


	public String getAnswer() {
		return answer;
	}


	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
	

}
