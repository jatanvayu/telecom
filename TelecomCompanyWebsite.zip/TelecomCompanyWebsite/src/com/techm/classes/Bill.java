package com.techm.classes;

import java.util.Date;

public class Bill {
	private int billId;
	private int amount;
	private String status;
	
	
	public Bill(int billId, int amount, String status) {
		super();
		this.billId = billId;
		this.amount = amount;
		this.status = status;
	}
	
	
	
	
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getBillId() {
		return billId;
	}
	public void setBillId(int billId) {
		this.billId = billId;
	}
	
	
	
	@Override
	public String toString() {
		return "Bill [billId=" + billId + ", amount=" + amount + ", status="
				+ status + "]";
	}
	
	
	

	
	
	
	

}
