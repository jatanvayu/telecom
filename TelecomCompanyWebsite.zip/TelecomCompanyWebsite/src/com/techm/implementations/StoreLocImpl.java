package com.techm.implementations;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;
import com.techm.connection.jdbcConnection;
import com.techm.interfaces.StoreLocDao;

public class StoreLocImpl implements StoreLocDao{
	
	jdbcConnection jcon = new jdbcConnection();
	Connection con;

	
	public String getAddresses(String city) {
		String addresses=null;
		String SQL="select addresses from store where city=?";
		jcon.getConnection();
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, city);
			ResultSet rs=ps.executeQuery();
			//Since multiple records are expected we use while
			if(rs.next())
			{
				addresses=rs.getString("addresses");
			}
			else
			{
				addresses="No addresses found!";
			}	
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			jcon.closeConnection();
		}
		
		return addresses;
		
		
	}

}
