package com.techm.implementations;

import java.util.ArrayList;

import com.techm.classes.Bill;
import com.techm.classes.Customer;
import com.techm.classes.Plan;
import com.techm.interfaces.BillDao;



public class BillImpl implements BillDao{

	
	

}
